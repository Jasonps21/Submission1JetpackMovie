package com.jason.movietvcatalog.data.source.remote.response

data class GenreResponse(
    var id: String,
    var name: String
)