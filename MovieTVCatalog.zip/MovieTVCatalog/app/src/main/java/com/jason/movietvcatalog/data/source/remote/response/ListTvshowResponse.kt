package com.jason.movietvcatalog.data.source.remote.response

data class ListTvshowResponse(
    var results: List<TvResponse>
)