package com.jason.movietvcatalog.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}