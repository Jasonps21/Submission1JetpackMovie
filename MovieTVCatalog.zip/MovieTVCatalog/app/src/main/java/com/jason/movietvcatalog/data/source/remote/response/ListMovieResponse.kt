package com.jason.movietvcatalog.data.source.remote.response

data class ListMovieResponse(
    var results: List<MovieResponse>
)