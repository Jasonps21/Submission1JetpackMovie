package com.jason.movietvcatalog.data.source.remote.response

data class ActorResponse(
    var character: String,
    var profile_path: String?,
    var name: String,
    var movie_id: String
)