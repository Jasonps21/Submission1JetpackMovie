package com.jason.movietvcatalog.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}